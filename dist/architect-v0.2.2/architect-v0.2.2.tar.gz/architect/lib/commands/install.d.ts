import { flags } from '@oclif/command';
import Listr from 'listr';
import Command from '../base';
import ServiceDependency from '../common/service-dependency';
export default class Install extends Command {
    static description: string;
    static flags: {
        help: import("@oclif/parser/lib/flags").IBooleanFlag<void>;
        prefix: flags.IOptionFlag<string | undefined>;
        recursive: import("@oclif/parser/lib/flags").IBooleanFlag<boolean>;
        verbose: import("@oclif/parser/lib/flags").IBooleanFlag<boolean>;
    };
    static args: {
        name: string;
        description: string;
        required: boolean;
    }[];
    run(): Promise<void>;
    tasks(): Promise<Listr.ListrTask[]>;
    get_tasks(service_dependency: ServiceDependency, recursive: boolean, _seen?: Set<ServiceDependency>): Listr.ListrTask[];
}
