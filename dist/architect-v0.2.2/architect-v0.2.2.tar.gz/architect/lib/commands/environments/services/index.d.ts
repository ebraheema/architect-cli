import Command from '../../../base';
export default class Services extends Command {
    static description: string;
    static aliases: string[];
    static args: {
        name: string;
        description: string;
        required: boolean;
    }[];
    static flags: {
        help: import("@oclif/parser/lib/flags").IBooleanFlag<void>;
    };
    run(): Promise<void>;
}
