import { flags } from '@oclif/command';
import Command from '../../base';
export default class CreateEnvironment extends Command {
    static description: string;
    static aliases: string[];
    static args: {
        name: string;
        description: string;
        parse: (value: string) => string;
    }[];
    static flags: {
        help: import("@oclif/parser/lib/flags").IBooleanFlag<void>;
        namespace: flags.IOptionFlag<string | undefined>;
        type: flags.IOptionFlag<string | undefined>;
        host: flags.IOptionFlag<string | undefined>;
        service_token: flags.IOptionFlag<string | undefined>;
        cluster_ca_certificate: flags.IOptionFlag<string | undefined>;
        verbose: import("@oclif/parser/lib/flags").IBooleanFlag<boolean>;
    };
    run(): Promise<void>;
    promptOptions(): Promise<any>;
}
