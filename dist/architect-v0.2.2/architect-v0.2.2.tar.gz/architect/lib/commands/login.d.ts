import { flags } from '@oclif/command';
import Command from '../base';
export default class Login extends Command {
    static description: string;
    static flags: {
        help: import("@oclif/parser/lib/flags").IBooleanFlag<void>;
        username: flags.IOptionFlag<string | undefined>;
        password: flags.IOptionFlag<string | undefined>;
    };
    run(): Promise<void>;
    promptOptions(): Promise<unknown>;
    login(username: string, password: string): Promise<void>;
}
