import Command from '@oclif/command';
import Config from '@oclif/config';
import { AxiosRequestConfig, Method } from 'axios';
import Listr from 'listr';
import { AppConfig } from './app-config';
export default abstract class ArchitectCommand extends Command {
    static tasks(this: any, argv?: string[], opts?: Config.LoadOptions): Promise<Listr.ListrTask[]>;
    protected static app_config: AppConfig;
    protected static architect: ArchitectClient;
    app_config: AppConfig;
    architect: ArchitectClient;
    init(): Promise<void>;
    catch(err: any): Promise<void>;
    tasks(): Promise<Listr.ListrTask[]>;
    _tasks(): Promise<Listr.ListrTask[] | undefined>;
    styled_json(obj: object): void;
}
declare class UserEntity {
    readonly access_token: string;
    readonly username: string;
    constructor(access_token: string, username: string);
}
declare class ArchitectClient {
    protected readonly app_config: AppConfig;
    protected _user?: Promise<UserEntity>;
    constructor(app_config: AppConfig);
    login(username: string, password: string): Promise<void>;
    logout(): Promise<void>;
    getUser(): Promise<UserEntity>;
    get(path: string, options?: AxiosRequestConfig): Promise<import("axios").AxiosResponse<any>>;
    put(path: string, options?: AxiosRequestConfig): Promise<import("axios").AxiosResponse<any>>;
    delete(path: string, options?: AxiosRequestConfig): Promise<import("axios").AxiosResponse<any>>;
    post(path: string, options?: AxiosRequestConfig): Promise<import("axios").AxiosResponse<any>>;
    refreshToken(): Promise<any>;
    protected _getUser(): Promise<UserEntity>;
    protected request(method: Method, path: string, options?: AxiosRequestConfig): Promise<import("axios").AxiosResponse<any>>;
}
export {};
