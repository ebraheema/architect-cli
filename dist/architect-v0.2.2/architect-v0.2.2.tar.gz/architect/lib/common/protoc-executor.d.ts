import ServiceDependency from './service-dependency';
declare namespace ProtocExecutor {
    const clear: (target: ServiceDependency) => Promise<void>;
    const execute: (dependency: ServiceDependency, target: ServiceDependency) => Promise<void>;
}
export default ProtocExecutor;
