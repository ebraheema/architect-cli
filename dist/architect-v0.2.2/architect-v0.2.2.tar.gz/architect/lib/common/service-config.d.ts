import ServiceParameter from './service-parameter';
import SUPPORTED_LANGUAGES from './supported-languages';
export default class ServiceConfig {
    static _require(path: string): any;
    static parsePathFromDependencyIdentifier(dependency_identifier: string, path_prefix?: string): string;
    static loadJSONFromPath(filepath: string): any;
    static loadFromPath(filepath: string): ServiceConfig;
    static writeToPath(filepath: string, config_json: object): void;
    static create(configJSON: any): ServiceConfig;
    static convertServiceNameToFolderName(service_name: string): string;
    name: string;
    version: string;
    description: string;
    keywords: string[];
    author: string;
    license: string;
    dependencies: {
        [s: string]: string;
    };
    parameters: {
        [s: string]: ServiceParameter;
    };
    api?: {
        type: string;
        definitions: string[];
    };
    datastores: {
        [key: string]: {
            image: string;
            port: string;
            parameters: {
                [key: string]: ServiceParameter;
            };
            host?: string;
        };
    };
    notifications: string[];
    subscriptions: object;
    language: SUPPORTED_LANGUAGES;
    host?: string;
    port: string;
    debug?: string;
    constructor();
    readonly full_name: string;
    readonly slug: string;
    getNormalizedName(): string;
    setName(name: string): this;
    setVersion(version: string): this;
    setDescription(description: string): this;
    setKeywords(keywords: string | string[]): this;
    setAuthor(author: string): this;
    setLicense(license: string): this;
    setDependencies(dependencies: {
        [s: string]: string;
    }): this;
    setParameters(parameters: {
        [s: string]: Partial<ServiceParameter>;
    }): this;
    setApi(api: {
        type: string;
        definitions: string[];
    }): this;
    setDatastores(datastores: {
        [key: string]: {
            image: string;
            port: string;
            parameters: {
                [key: string]: ServiceParameter;
            };
            host?: string;
        };
    }): this;
    setNotifications(notifications: string[]): this;
    setSubscriptions(subscriptions: object): this;
    setLanguage(language: SUPPORTED_LANGUAGES): this;
    setPort(port: string): this;
    setDebug(debug: string): this;
    isScript(): boolean;
}
export declare class MissingConfigFileError extends Error {
    constructor(filepath: string);
}
export declare class UnsupportedDependencyIdentifierError extends TypeError {
    constructor(identifier: string);
}
