export default class ServiceParameter {
    description?: string;
    default?: string | number | null;
    alias?: string;
    required: boolean;
    constructor(partial?: Partial<ServiceParameter>);
}
