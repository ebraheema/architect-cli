declare enum MANAGED_PATHS {
    ARCHITECT_JSON = "architect.json",
    DEPENDENCY_STUBS_DIRECTORY = "architect_services",
    HIDDEN = ".architect",
    DEPLOYMENT_CONFIGS = "deployments"
}
export default MANAGED_PATHS;
