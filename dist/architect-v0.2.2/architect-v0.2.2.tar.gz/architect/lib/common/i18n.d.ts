export declare const INIT_INTRO_TEXT: string;
