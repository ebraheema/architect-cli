export declare class AppConfig {
    readonly debug: boolean;
    readonly oauth_domain: string;
    readonly oauth_client_id: string;
    readonly default_registry_host: string;
    readonly api_host: string;
    constructor();
}
